# GROUPE 4
Kahina Derbene ( Scrum Master)
Hemaizi Camilia, Zinn Edinne Lakhdari (Membre equipe Scrum)


#  premiere version
Dans cette premiere version on devez crée un parser qui convertit un fichier pdf en txt avec la structure suivante :
le nom du fichier d'origine (dans une ligne )
le titre du papier (dans une ligne )
le résumé ou abstract de l'auteur (dans une ligne)


Afin d'executer le parser tapez la commande suivante :

     python3 parser.py Papers -t 


   la commande crée un dossier fichierTXT qui contient les fichier en .txt



